UIPages['FolderOptions'] = {}

UIPages['FolderOptions'].Init = function()
  local onoff = FolderOptions:Get('ShowAll')
  UISwitch.Set('$Switch.FolderOptShowAll', onoff)

  onoff = FolderOptions:Get('ShowExt') + 1  -- trick: -1(true), 0(false) => 0(false), 1(true)
  UISwitch.Set('$Switch.FolderOptShowExt', onoff)

  onoff = FolderOptions:Get('ShowSuperHidden') + 1
  UISwitch.Set('$Switch.FolderOptShowSuperHidden', onoff)
end

UI.OnChanged['$Switch.FolderOptShowAll'] = function(val)
  FolderOptions:Set('ShowAll', val)
end

UI.OnChanged['$Switch.FolderOptShowExt'] = function(val)
  FolderOptions:Set('ShowExt', val - 1)
end

UI.OnChanged['$Switch.FolderOptShowSuperHidden'] = function(val)
  FolderOptions:Set('ShowSuperHidden', val - 1)
end

