

function NavTab_OnClick(self, tab, ctrl)
    App:Debug('NavTab_OnClick - ' .. tab  .. ' ' .. tostring(ctrl))
  
    if UI.Inited == 1 then
      if display_applybtn.visible == 1 then
        display_applybtn_click()
      end
    end
  
    self:DefOnClick(tab)
  end
  
  function NavTab_Init()
    local nav = UITab.New('$Nav')
    nav:BindLayout('TabLayoutMain')
    nav:SetList({
      'Display',
      'Background',
      'Colors',
      'FolderOptions',
      'Taskbar'
    })
    nav.OnClick = NavTab_OnClick
    return nav
  end

  